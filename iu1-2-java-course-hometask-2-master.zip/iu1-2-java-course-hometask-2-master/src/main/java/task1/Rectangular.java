package task1;

public class Rectangular implements Figure2D{
}
