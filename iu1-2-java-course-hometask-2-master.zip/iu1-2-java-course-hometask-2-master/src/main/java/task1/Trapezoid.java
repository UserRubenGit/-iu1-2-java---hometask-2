package task1;

public class Trapezoid implements Figure2D{
}
