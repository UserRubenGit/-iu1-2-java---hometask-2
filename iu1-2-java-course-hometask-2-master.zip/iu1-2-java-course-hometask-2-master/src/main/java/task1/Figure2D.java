package task1;

public abstract class Figure2D {
    abstract double area();
}
