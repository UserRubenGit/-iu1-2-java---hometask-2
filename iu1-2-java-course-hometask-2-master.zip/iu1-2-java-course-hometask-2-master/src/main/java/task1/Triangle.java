package task1;

public class Triangle implements Figure2D{
}
