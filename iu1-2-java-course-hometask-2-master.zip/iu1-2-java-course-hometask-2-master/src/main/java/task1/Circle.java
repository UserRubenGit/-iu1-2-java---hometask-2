package task1;

public class Circle implements Figure2D{
}
